/****************************************************************************
** Meta object code from reading C++ file 'tabdialogSignalMessage.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../tabdialogSignalMessage.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tabdialogSignalMessage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_DefinitionTabMsgSign_t {
    QByteArrayData data[1];
    char stringdata0[21];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_DefinitionTabMsgSign_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_DefinitionTabMsgSign_t qt_meta_stringdata_DefinitionTabMsgSign = {
    {
QT_MOC_LITERAL(0, 0, 20) // "DefinitionTabMsgSign"

    },
    "DefinitionTabMsgSign"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_DefinitionTabMsgSign[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void DefinitionTabMsgSign::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject DefinitionTabMsgSign::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_DefinitionTabMsgSign.data,
      qt_meta_data_DefinitionTabMsgSign,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *DefinitionTabMsgSign::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DefinitionTabMsgSign::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_DefinitionTabMsgSign.stringdata0))
        return static_cast<void*>(const_cast< DefinitionTabMsgSign*>(this));
    return QWidget::qt_metacast(_clname);
}

int DefinitionTabMsgSign::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_MessageTabMsgSign_t {
    QByteArrayData data[1];
    char stringdata0[18];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MessageTabMsgSign_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MessageTabMsgSign_t qt_meta_stringdata_MessageTabMsgSign = {
    {
QT_MOC_LITERAL(0, 0, 17) // "MessageTabMsgSign"

    },
    "MessageTabMsgSign"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MessageTabMsgSign[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void MessageTabMsgSign::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject MessageTabMsgSign::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_MessageTabMsgSign.data,
      qt_meta_data_MessageTabMsgSign,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MessageTabMsgSign::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MessageTabMsgSign::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MessageTabMsgSign.stringdata0))
        return static_cast<void*>(const_cast< MessageTabMsgSign*>(this));
    return QWidget::qt_metacast(_clname);
}

int MessageTabMsgSign::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_SignalsTabMsgSign_t {
    QByteArrayData data[1];
    char stringdata0[18];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SignalsTabMsgSign_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SignalsTabMsgSign_t qt_meta_stringdata_SignalsTabMsgSign = {
    {
QT_MOC_LITERAL(0, 0, 17) // "SignalsTabMsgSign"

    },
    "SignalsTabMsgSign"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SignalsTabMsgSign[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void SignalsTabMsgSign::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject SignalsTabMsgSign::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_SignalsTabMsgSign.data,
      qt_meta_data_SignalsTabMsgSign,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *SignalsTabMsgSign::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SignalsTabMsgSign::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_SignalsTabMsgSign.stringdata0))
        return static_cast<void*>(const_cast< SignalsTabMsgSign*>(this));
    return QWidget::qt_metacast(_clname);
}

int SignalsTabMsgSign::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_ReceiversTabMsgSign_t {
    QByteArrayData data[1];
    char stringdata0[20];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ReceiversTabMsgSign_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ReceiversTabMsgSign_t qt_meta_stringdata_ReceiversTabMsgSign = {
    {
QT_MOC_LITERAL(0, 0, 19) // "ReceiversTabMsgSign"

    },
    "ReceiversTabMsgSign"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ReceiversTabMsgSign[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void ReceiversTabMsgSign::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject ReceiversTabMsgSign::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_ReceiversTabMsgSign.data,
      qt_meta_data_ReceiversTabMsgSign,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ReceiversTabMsgSign::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ReceiversTabMsgSign::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ReceiversTabMsgSign.stringdata0))
        return static_cast<void*>(const_cast< ReceiversTabMsgSign*>(this));
    return QWidget::qt_metacast(_clname);
}

int ReceiversTabMsgSign::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_ValueDescriptionsTabMsgSign_t {
    QByteArrayData data[1];
    char stringdata0[28];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ValueDescriptionsTabMsgSign_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ValueDescriptionsTabMsgSign_t qt_meta_stringdata_ValueDescriptionsTabMsgSign = {
    {
QT_MOC_LITERAL(0, 0, 27) // "ValueDescriptionsTabMsgSign"

    },
    "ValueDescriptionsTabMsgSign"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ValueDescriptionsTabMsgSign[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void ValueDescriptionsTabMsgSign::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject ValueDescriptionsTabMsgSign::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_ValueDescriptionsTabMsgSign.data,
      qt_meta_data_ValueDescriptionsTabMsgSign,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ValueDescriptionsTabMsgSign::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ValueDescriptionsTabMsgSign::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ValueDescriptionsTabMsgSign.stringdata0))
        return static_cast<void*>(const_cast< ValueDescriptionsTabMsgSign*>(this));
    return QWidget::qt_metacast(_clname);
}

int ValueDescriptionsTabMsgSign::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_AttributesTabMsgSign_t {
    QByteArrayData data[1];
    char stringdata0[21];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_AttributesTabMsgSign_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_AttributesTabMsgSign_t qt_meta_stringdata_AttributesTabMsgSign = {
    {
QT_MOC_LITERAL(0, 0, 20) // "AttributesTabMsgSign"

    },
    "AttributesTabMsgSign"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_AttributesTabMsgSign[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void AttributesTabMsgSign::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject AttributesTabMsgSign::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_AttributesTabMsgSign.data,
      qt_meta_data_AttributesTabMsgSign,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *AttributesTabMsgSign::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AttributesTabMsgSign::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_AttributesTabMsgSign.stringdata0))
        return static_cast<void*>(const_cast< AttributesTabMsgSign*>(this));
    return QWidget::qt_metacast(_clname);
}

int AttributesTabMsgSign::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_CommentTabMsgSign_t {
    QByteArrayData data[1];
    char stringdata0[18];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CommentTabMsgSign_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CommentTabMsgSign_t qt_meta_stringdata_CommentTabMsgSign = {
    {
QT_MOC_LITERAL(0, 0, 17) // "CommentTabMsgSign"

    },
    "CommentTabMsgSign"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CommentTabMsgSign[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void CommentTabMsgSign::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject CommentTabMsgSign::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_CommentTabMsgSign.data,
      qt_meta_data_CommentTabMsgSign,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *CommentTabMsgSign::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CommentTabMsgSign::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_CommentTabMsgSign.stringdata0))
        return static_cast<void*>(const_cast< CommentTabMsgSign*>(this));
    return QWidget::qt_metacast(_clname);
}

int CommentTabMsgSign::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_TabDialogSignalMessage_t {
    QByteArrayData data[1];
    char stringdata0[23];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TabDialogSignalMessage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TabDialogSignalMessage_t qt_meta_stringdata_TabDialogSignalMessage = {
    {
QT_MOC_LITERAL(0, 0, 22) // "TabDialogSignalMessage"

    },
    "TabDialogSignalMessage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TabDialogSignalMessage[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void TabDialogSignalMessage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject TabDialogSignalMessage::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_TabDialogSignalMessage.data,
      qt_meta_data_TabDialogSignalMessage,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *TabDialogSignalMessage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TabDialogSignalMessage::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_TabDialogSignalMessage.stringdata0))
        return static_cast<void*>(const_cast< TabDialogSignalMessage*>(this));
    return QDialog::qt_metacast(_clname);
}

int TabDialogSignalMessage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
